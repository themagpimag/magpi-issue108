# Write your code here :-)
import board
import digitalio
import gamepad
import time
import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode

kbd = Keyboard(usb_hid.devices)

B_UP = 1 << 0
B_DOWN = 1 << 1
B_LEFT = 1 << 2
B_RIGHT = 1 << 3
B_1 = 1 << 4
B_2 = 1 << 5
B_3 = 1 << 6
B_4 = 1 << 7


keycodes = [Keycode.UP_ARROW, Keycode.DOWN_ARROW, Keycode.LEFT_ARROW, Keycode.RIGHT_ARROW,
            Keycode.X, Keycode.Z, Keycode.SPACE, Keycode.ENTER]

pad = gamepad.GamePad(
    digitalio.DigitalInOut(board.GP12),
    digitalio.DigitalInOut(board.GP14),
    digitalio.DigitalInOut(board.GP9),
    digitalio.DigitalInOut(board.GP15),
    digitalio.DigitalInOut(board.GP16),
    digitalio.DigitalInOut(board.GP17),
    digitalio.DigitalInOut(board.GP18),
    digitalio.DigitalInOut(board.GP20),
)

last_pressed = 0

print("h343")

while True:
    this_pressed = pad.get_pressed()
    if (this_pressed != last_pressed):
        #new keypresses
        for i in range(8):
            if (this_pressed & 1<<i) and not (last_pressed & 1<<i):
                kbd.press(keycodes[i])
            if (last_pressed & 1<<i) and not (this_pressed & 1<<i):
                kbd.release(keycodes[i])
        last_pressed = this_pressed
    time.sleep(0.01)